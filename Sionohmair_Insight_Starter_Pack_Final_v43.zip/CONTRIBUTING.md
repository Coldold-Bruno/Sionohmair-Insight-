
# 🤝 Guide de Contribution – Sionohmair Insight

Bienvenue et merci de contribuer à **Sionohmair Insight** 🌌  
Ce guide te montre comment participer efficacement à l’évolution de cette application vibratoire de conscience.

---

## 🔧 Pré-requis

- Node.js v18+
- Compte Supabase (accès aux clés via `.env.local`)
- Connaissances en React / Tailwind / Supabase

---

## 🚀 Mise en place locale

```bash
git clone https://github.com/ton-user/sionohmair-insight.git
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

---

## 🧱 Structure des branches

- `main` → version stable et déployée
- `dev` → intégration des nouvelles fonctionnalités
- `feature/xxx` → nouvelles features spécifiques
- `fix/xxx` → correctifs

---

## ✍️ Conventions de code

- Utiliser `camelCase` pour les variables JavaScript
- Composants React en `PascalCase`
- Fichiers par fonction : `services/`, `pages/`, `context/`
- Commente ton code si la logique est complexe (surtout EEG/coaching)

---

## 🔁 Processus de contribution

1. **Fork** le repo
2. Crée une branche (`git checkout -b feature/monModule`)
3. Code ton amélioration
4. **Teste en local**
5. Fais une Pull Request vers `dev`
6. Attends la revue et l’intégration

---

## 📦 Bonnes pratiques

- Déploie sur une branche `preview` si tu veux une démo Vercel
- Vérifie l’impact sur Supabase (tables, permissions)
- Garde en tête les fondements du **Sionohmair** :
  > Chaque ligne de code vibre. Garde-la consciente, sobre et alignée.

---

## ✨ Style de commit recommandé

Utilise le format [Conventional Commits](https://www.conventionalcommits.org):

- `feat:` pour une nouvelle fonctionnalité
- `fix:` pour un bug
- `docs:` pour la documentation
- `refactor:` pour une amélioration de structure
- `chore:` pour des tâches de maintenance

**Exemple :**
```
feat: ajout du module de session EEG multi-niveaux
```

---

## 🙏 Remerciements

Toute aide est précieuse. Merci de vibrer avec nous 🌱  
Pour toute question, contacte **Coldold Bruno Baama** via LinkedIn ou GitHub.

---

