# 🚀 Instructions d'installation pour le déploiement complet de Sionohmair Insight (Front-End)

Ce document guide votre développeur étape par étape pour déployer l'application **Sionohmair Insight** dans son intégralité.

---

## 🔧 1. Prérequis

- Node.js ≥ 16
- NPM ≥ 8
- Compte Firebase configuré (Firestore + Authentication)
- Clés Firebase renseignées dans `src/config/firebase-config.js`

---

## 📦 2. Installation des dépendances

Ouvrez un terminal dans le dossier `frontend` :

```bash
cd frontend
npm install
```

### 📚 Dépendances supplémentaires nécessaires pour le rapport PDF

```bash
npm install jspdf html2canvas
```

---

## ⚙️ 3. Lancement de l'application en développement

```bash
npm run dev
```

Accédez à : `http://localhost:5173`

---

## 📁 4. Structure de l'application

- `src/pages/` :
  - `FirebaseLogin.jsx` : Authentification
  - `UserManager.jsx` : Gestion utilisateurs + export
  - `VisualEEGByUser.jsx` : Visualisation EEG individuelle
  - `AnalyseSionohmair.jsx` : Analyse EEG automatisée
  - `SionohmairReport.jsx` : Rapport PDF + graphique

---

## 🔐 5. Configuration Firebase

Créez un fichier `firebase-config.js` :

```javascript
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "VOTRE_CLE",
  authDomain: "VOTRE_DOMAINE",
  projectId: "VOTRE_ID",
  storageBucket: "VOTRE_BUCKET",
  messagingSenderId: "VOTRE_SENDER_ID",
  appId: "VOTRE_APP_ID",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
```

---

## ✅ 6. Prêt pour le déploiement

Une fois les étapes complétées :

```bash
npm run build
```

Vous pouvez ensuite héberger les fichiers générés via Firebase Hosting, Netlify, Vercel ou tout autre hébergeur.

---

*Document généré automatiquement – Sionohmair Insight Deployment*