import i18n from "i18next";
import { initReactI18next } from "react-i18next";

import translationEN from "./locales/en.json";
import translationFR from "./locales/fr.json";
import translationES from "./locales/es.json";
import translationDE from "./locales/de.json";
import translationAR from "./locales/ar.json";
import translationZH from "./locales/zh.json";
import translationRU from "./locales/ru.json";
import translationPT from "./locales/pt.json";
import translationHI from "./locales/hi.json";
import translationJA from "./locales/ja.json";

const resources = {
  en: { translation: translationEN },
  fr: { translation: translationFR },
  es: { translation: translationES },
  de: { translation: translationDE },
  ar: { translation: translationAR },
  zh: { translation: translationZH },
  ru: { translation: translationRU },
  pt: { translation: translationPT },
  hi: { translation: translationHI },
  ja: { translation: translationJA }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "fr",
    fallbackLng: "en",
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;