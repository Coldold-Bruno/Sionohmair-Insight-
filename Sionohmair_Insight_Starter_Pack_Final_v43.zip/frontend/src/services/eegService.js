
import { supabase } from '../lib/supabaseClient';

// Ajouter une session EEG
export const addEEGSession = async ({ user_id, date, dominante, resume }) => {
  const { data, error } = await supabase
    .from('sessions_eeg')
    .insert([{ user_id, date, dominante, résumé: resume }]);

  if (error) throw error;
  return data;
};

// Récupérer les sessions EEG d'un utilisateur
export const getEEGSessions = async (user_id) => {
  const { data, error } = await supabase
    .from('sessions_eeg')
    .select('*')
    .eq('user_id', user_id)
    .order('date', { ascending: false });

  if (error) throw error;
  return data;
};
