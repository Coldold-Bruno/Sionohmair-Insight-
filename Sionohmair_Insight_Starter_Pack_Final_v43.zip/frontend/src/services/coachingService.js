
import { supabase } from '../lib/supabaseClient';

// Ajouter une session de coaching
export const addCoachingSession = async ({ user_id, date, type, resume }) => {
  const { data, error } = await supabase
    .from('sessions_coaching')
    .insert([{ user_id, date, type, résumé: resume }]);

  if (error) throw error;
  return data;
};

// Récupérer les sessions de coaching
export const getCoachingSessions = async (user_id) => {
  const { data, error } = await supabase
    .from('sessions_coaching')
    .select('*')
    .eq('user_id', user_id)
    .order('date', { ascending: false });

  if (error) throw error;
  return data;
};
