import React, { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../config/firebase-config";
import jsPDF from "jspdf";
import "jspdf-autotable";

const ExportUsersPDF = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const snapshot = await getDocs(collection(db, "users"));
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsers(data);
    };
    fetchData();
  }, []);

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.text("Sionohmair – Export PDF des Utilisateurs", 14, 16);
    doc.setFontSize(10);

    const tableColumn = ["ID", "Email", "Rôle", "Date de création"];
    const tableRows = users.map(user => [
      user.id,
      user.email,
      user.role,
      user.created,
    ]);

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 22,
      theme: "grid",
    });

    doc.save("sionohmair_utilisateurs.pdf");
  };

  return (
    <div style={{ marginTop: "10px" }}>
      <button onClick={generatePDF} style={{ padding: "8px 16px" }}>
        🧾 Exporter PDF
      </button>
    </div>
  );
};

export default ExportUsersPDF;