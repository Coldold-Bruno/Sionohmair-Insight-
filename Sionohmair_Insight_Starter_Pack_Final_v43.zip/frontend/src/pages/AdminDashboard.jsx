import React from "react";
import { useLocation } from "react-router-dom";
import UserManager from "./UserManager";

const AdminDashboard = () => {
  const location = useLocation();
  const query = new URLSearchParams(location.search);
  const role = query.get("role") || "user";

  const stats = [
    { region: "Europe francophone", users: 1234, avgEEG: "Alpha élevé", dominantBelief: "Spiritualité intérieure" },
    { region: "Amérique anglophone", users: 980, avgEEG: "Theta", dominantBelief: "Individualisme conscient" },
    { region: "Monde arabe", users: 732, avgEEG: "Delta", dominantBelief: "Foi divine structurante" },
    { region: "Asie orientale", users: 860, avgEEG: "Gamma", dominantBelief: "Harmonie intérieure collective" }
  ];

  return (
    <div style={{ padding: "20px" }}>
      <h2>🧠 Tableau de bord – {role === "admin" ? "Administrateur" : role === "coach" ? "Coach" : "Utilisateur"}</h2>

      {role === "admin" && (
        <>
          <p style={{ color: "green" }}>Accès complet au tableau + gestion utilisateurs</p>
          <UserManager />
        </>
      )}
      {role === "coach" && (
        <p style={{ color: "orange" }}>Accès aux analyses EEG et croyances</p>
      )}
      {role === "user" && (
        <p style={{ color: "gray" }}>Accès restreint – demande une autorisation pour consulter les données avancées.</p>
      )}

      {(role === "admin" || role === "coach") && (
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
          <thead>
            <tr style={{ background: "#eee" }}>
              <th style={{ padding: "8px", border: "1px solid #ccc" }}>Région</th>
              <th style={{ padding: "8px", border: "1px solid #ccc" }}>Utilisateurs</th>
              <th style={{ padding: "8px", border: "1px solid #ccc" }}>EEG moyen</th>
              <th style={{ padding: "8px", border: "1px solid #ccc" }}>Croyance dominante</th>
            </tr>
          </thead>
          <tbody>
            {stats.map((item, index) => (
              <tr key={index}>
                <td style={{ padding: "8px", border: "1px solid #ccc" }}>{item.region}</td>
                <td style={{ padding: "8px", border: "1px solid #ccc" }}>{item.users}</td>
                <td style={{ padding: "8px", border: "1px solid #ccc" }}>{item.avgEEG}</td>
                <td style={{ padding: "8px", border: "1px solid #ccc" }}>{item.dominantBelief}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AdminDashboard;