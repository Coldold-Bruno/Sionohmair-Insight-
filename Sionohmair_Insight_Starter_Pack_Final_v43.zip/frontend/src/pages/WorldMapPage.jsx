import React from "react";

const WorldMapPage = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Carte mondiale des langues Sionohmair</h2>
      <iframe
        src="/Sionohmair_Insight_Carte_Mondiale_Langues.html"
        title="Carte mondiale Sionohmair"
        style={{ width: "100%", height: "80vh", border: "none" }}
      />
    </div>
  );
};

export default WorldMapPage;