import React, { useEffect, useState } from "react";
import { db } from "../config/firebase-config";
import { collection, getDocs } from "firebase/firestore";

const ExportUsers = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const load = async () => {
      const snapshot = await getDocs(collection(db, "users"));
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setUsers(data);
    };
    load();
  }, []);

  const handleExport = () => {
    const header = ["ID", "Email", "Role", "Created"];
    const rows = users.map(u => [u.id, u.email, u.role, u.created]);

    const csvContent = [header, ...rows]
      .map(row => row.map(String).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "sionohmair_users_export.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ marginTop: "20px" }}>
      <button onClick={handleExport} style={{ padding: "8px 16px" }}>
        📤 Exporter en CSV
      </button>
    </div>
  );
};

export default ExportUsers;