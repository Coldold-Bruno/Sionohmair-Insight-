import React, { useEffect, useState } from "react";
import { db } from "../config/firebase-config";
import {
  collection,
  getDocs,
  addDoc,
  query,
  where,
  Timestamp
} from "firebase/firestore";

const EEGCroyanceForm = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState("");
  const [eegData, setEegData] = useState("");
  const [beliefData, setBeliefData] = useState("");

  useEffect(() => {
    const fetchUsers = async () => {
      const snapshot = await getDocs(collection(db, "users"));
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsers(data);
    };
    fetchUsers();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedUser || !eegData || !beliefData) return;

    await addDoc(collection(db, "eeg_croyances"), {
      userId: selectedUser,
      eeg: eegData,
      croyance: beliefData,
      timestamp: Timestamp.now()
    });

    setSelectedUser("");
    setEegData("");
    setBeliefData("");
    alert("Enregistrement réussi !");
  };

  return (
    <div style={{ padding: "20px", marginTop: "20px" }}>
      <h3>🧠 Ajouter des données EEG & Croyance</h3>
      <form onSubmit={handleSubmit}>
        <select
          value={selectedUser}
          onChange={(e) => setSelectedUser(e.target.value)}
          required
          style={{ padding: "6px", marginBottom: "10px", width: "100%" }}
        >
          <option value="">– Sélectionner un utilisateur –</option>
          {users.map((u) => (
            <option key={u.id} value={u.id}>{u.email}</option>
          ))}
        </select>
        <textarea
          placeholder="Données EEG"
          value={eegData}
          onChange={(e) => setEegData(e.target.value)}
          required
          style={{ width: "100%", padding: "8px", marginBottom: "10px" }}
        />
        <textarea
          placeholder="Croyance associée"
          value={beliefData}
          onChange={(e) => setBeliefData(e.target.value)}
          required
          style={{ width: "100%", padding: "8px", marginBottom: "10px" }}
        />
        <button type="submit" style={{ padding: "8px 16px" }}>💾 Enregistrer</button>
      </form>
    </div>
  );
};

export default EEGCroyanceForm;