import React, { useEffect, useState } from "react";
import { db } from "../config/firebase-config";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
} from "firebase/firestore";

const UserManager = () => {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ email: "", role: "user", created: "" });
  const [editId, setEditId] = useState(null);

  const userRef = collection(db, "users");

  const loadUsers = async () => {
    const snapshot = await getDocs(userRef);
    const data = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    setUsers(data);
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editId) {
      const userDoc = doc(db, "users", editId);
      await updateDoc(userDoc, form);
    } else {
      await addDoc(userRef, { ...form });
    }
    setForm({ email: "", role: "user", created: "" });
    setEditId(null);
    loadUsers();
  };

  const handleEdit = (user) => {
    setForm(user);
    setEditId(user.id);
  };

  const handleDelete = async (id) => {
    await deleteDoc(doc(db, "users", id));
    loadUsers();
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>👥 Gestion dynamique des utilisateurs Firebase</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
        <input
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
          style={{ padding: "6px", marginRight: "10px" }}
        />
        <select
          name="role"
          value={form.role}
          onChange={handleChange}
          style={{ padding: "6px", marginRight: "10px" }}
        >
          <option value="admin">admin</option>
          <option value="coach">coach</option>
          <option value="user">user</option>
        </select>
        <input
          name="created"
          placeholder="Date de création (ex: 2025-06-18)"
          value={form.created}
          onChange={handleChange}
          style={{ padding: "6px", marginRight: "10px" }}
        />
        <button type="submit" style={{ padding: "6px 12px" }}>
          {editId ? "Modifier" : "Ajouter"}
        </button>
      </form>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ backgroundColor: "#f0f0f0" }}>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Email</th>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Rôle</th>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Créé le</th>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>{u.email}</td>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>{u.role}</td>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>{u.created}</td>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>
                <button onClick={() => handleEdit(u)} style={{ marginRight: "6px" }}>✏️</button>
                <button onClick={() => handleDelete(u.id)}>🗑️</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

import ExportUsers from "./ExportUsers";
import ExportUsersPDF from "./ExportUsersPDF";
import EEGCroyanceForm from "./EEGCroyanceForm";

  return (<>

    <div style={{ padding: "20px" }}>
      <h2>👥 Gestion dynamique des utilisateurs Firebase</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
        <input
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
          style={{ padding: "6px", marginRight: "10px" }}
        />
        <select
          name="role"
          value={form.role}
          onChange={handleChange}
          style={{ padding: "6px", marginRight: "10px" }}
        >
          <option value="admin">admin</option>
          <option value="coach">coach</option>
          <option value="user">user</option>
        </select>
        <input
          name="created"
          placeholder="Date de création (ex: 2025-06-18)"
          value={form.created}
          onChange={handleChange}
          style={{ padding: "6px", marginRight: "10px" }}
        />
        <button type="submit" style={{ padding: "6px 12px" }}>
          {editId ? "Modifier" : "Ajouter"}
        </button>
      </form>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ backgroundColor: "#f0f0f0" }}>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Email</th>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Rôle</th>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Créé le</th>
            <th style={{ padding: "8px", border: "1px solid #ccc" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>{u.email}</td>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>{u.role}</td>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>{u.created}</td>
              <td style={{ padding: "8px", border: "1px solid #ccc" }}>
                <button onClick={() => handleEdit(u)} style={{ marginRight: "6px" }}>✏️</button>
                <button onClick={() => handleDelete(u.id)}>🗑️</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    <ExportUsers />
<ExportUsersPDF />
<EEGCroyanceForm /></div>
  );
};

export default UserManager;
// Page VisualEEGByUser importée et prête à l’emploi
