
import React, { useState } from 'react';
import { supabase } from '../lib/supabaseClient';

const AuthPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [message, setMessage] = useState('');

  const handleAuth = async () => {
    const fn = isSignUp ? supabase.auth.signUp : supabase.auth.signInWithPassword;
    const { data, error } = await fn({ email, password });
    if (error) setMessage(error.message);
    else setMessage('Email envoyé ou connexion réussie');
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-white">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">{isSignUp ? 'Créer un compte' : 'Se connecter'}</h2>
      <input type="email" placeholder="Email" className="border p-2 mb-2 w-72"
        value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Mot de passe" className="border p-2 mb-2 w-72"
        value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleAuth}
        className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
        {isSignUp ? 'Créer un compte' : 'Connexion'}
      </button>
      <p onClick={() => setIsSignUp(!isSignUp)} className="mt-4 cursor-pointer text-blue-600">
        {isSignUp ? 'Déjà inscrit ? Connectez-vous' : 'Créer un nouveau compte'}
      </p>
      {message && <p className="mt-4 text-red-600">{message}</p>}
    </div>
  );
};

export default AuthPage;
