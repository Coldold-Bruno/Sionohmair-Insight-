import React, { useEffect, useState } from "react";
import { db } from "../config/firebase-config";
import { collection, getDocs } from "firebase/firestore";

const AnalyseSionohmair = () => {
  const [results, setResults] = useState([]);

  useEffect(() => {
    const analyser = async () => {
      const snapshot = await getDocs(collection(db, "eeg_croyances"));
      const entries = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      const grouped = {};
      entries.forEach(e => {
        if (!grouped[e.userId]) grouped[e.userId] = [];
        grouped[e.userId].push(e);
      });

      const analyses = Object.entries(grouped).map(([userId, data]) => {
        const intensities = data.map(d =>
          parseFloat(d.eeg.match(/\d+\.?\d*/g)?.[0] || 0)
        );
        const moyenne = intensities.reduce((a, b) => a + b, 0) / intensities.length || 0;

        let niveau = "Faible";
        if (moyenne > 40) niveau = "Élevé";
        else if (moyenne > 20) niveau = "Modéré";

        return {
          userId,
          moyenneEEG: moyenne.toFixed(2),
          niveauVibratoire: niveau,
          croyances: data.map(d => d.croyance).slice(0, 3)
        };
      });

      setResults(analyses);
    };

    analyser();
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>🔍 Analyse Sionohmair automatisée</h2>
      <ul>
        {results.map((res, i) => (
          <li key={i} style={{ marginBottom: "16px" }}>
            <strong>Utilisateur :</strong> {res.userId}<br />
            <strong>Moyenne EEG :</strong> {res.moyenneEEG}<br />
            <strong>Niveau vibratoire :</strong> {res.niveauVibratoire}<br />
            <strong>Croyances principales :</strong>
            <ul>
              {res.croyances.map((c, idx) => <li key={idx}>– {c}</li>)}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AnalyseSionohmair;