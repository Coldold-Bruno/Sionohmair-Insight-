
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export default function LandingPage() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Formulaire soumis :", form);
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 p-6 flex flex-col items-center">
      <div className="max-w-3xl text-center mt-10">
        <h1 className="text-5xl font-bold mb-4">Sionohmair Insight</h1>
        <p className="text-lg text-gray-700 mb-8">
          Une application vibratoire pour explorer la conscience humaine. EEG, coaching cognitif, et cartographie des croyances réunis dans une seule interface.
        </p>
        <Button className="text-lg px-6 py-3 rounded-full mb-12" onClick={() => navigate('/auth')}>
          Tester l'application
        </Button>
      </div>

      <div className="w-full max-w-2xl p-6 border shadow rounded-2xl bg-gray-50">
        <h2 className="text-2xl font-semibold mb-4 text-center">🌿 Contact & Newsletter</h2>
        {submitted ? (
          <p className="text-green-700 text-center">Merci pour votre message ! 🌟</p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              name="name"
              placeholder="Votre nom"
              value={form.name}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded"
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Votre email"
              value={form.email}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded"
              required
            />
            <textarea
              name="message"
              placeholder="Votre message ou intention"
              value={form.message}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded"
              rows={4}
            ></textarea>
            <label className="text-sm block">
              <input type="checkbox" className="mr-2" required />
              Je souhaite recevoir la newsletter du projet Sionohmair.
            </label>
            <Button className="w-full py-2" type="submit">Envoyer ✨</Button>
          </form>
        )}
      </div>

      <footer className="mt-20 text-sm text-gray-500">
        &copy; {new Date().getFullYear()} Coldold Bruno Baama – Tous droits réservés
      </footer>
    </div>
  );
}
