import React, { useRef, useEffect, useState } from "react";
import { db } from "../config/firebase-config";
import { collection, getDocs } from "firebase/firestore";
import { Bar } from "react-chartjs-2";
import "chart.js/auto";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

const SionohmairReport = () => {
  const chartRef = useRef(null);
  const [dataReady, setDataReady] = useState(false);
  const [chartData, setChartData] = useState({});
  const [table, setTable] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const snapshot = await getDocs(collection(db, "eeg_croyances"));
      const entries = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Compute average EEG per user
      const userGroups = {};
      entries.forEach(e => {
        if (!userGroups[e.userId]) userGroups[e.userId] = [];
        userGroups[e.userId].push(e);
      });

      const labels = [];
      const values = [];
      const tableRows = [];

      Object.entries(userGroups).forEach(([uid, items]) => {
        const avg = items.reduce((acc, cur) => {
          const val = parseFloat(cur.eeg.match(/\d+\.?\d*/g)?.[0] || 0);
          return acc + val;
        }, 0) / items.length || 0;
        labels.push(uid.substring(0, 6) + "...");
        values.push(avg.toFixed(2));
        tableRows.push({ uid, avg: avg.toFixed(2), samples: items.length });
      });

      setChartData({
        labels,
        datasets: [
          {
            label: "Moyenne EEG",
            data: values,
            backgroundColor: "rgba(54, 162, 235, 0.5)",
          },
        ],
      });
      setTable(tableRows);
      setDataReady(true);
    };

    fetchData();
  }, []);

  const generatePDF = async () => {
    const pdf = new jsPDF("p", "mm", "a4");
    pdf.text("Rapport Sionohmair - Analyse EEG", 14, 16);
    // Capture chart
    const chartCanvas = chartRef.current;
    if (chartCanvas) {
      const canvas = await html2canvas(chartCanvas);
      const imgData = canvas.toDataURL("image/png");
      pdf.addImage(imgData, "PNG", 10, 25, 190, 80);
    }
    // Table
    pdf.setFontSize(10);
    let y = 110;
    pdf.text("Utilisateurs - Moyenne EEG :", 14, y);
    y += 6;
    table.forEach((row) => {
      pdf.text(
        `${row.uid} | Moyenne: ${row.avg} | Echantillons: ${row.samples}`,
        14,
        y
      );
      y += 6;
    });
    pdf.save("rapport_sionohmair.pdf");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Rapport Sionohmair : Visualisation & PDF</h2>
      {dataReady ? (
        <>
          <div style={{ maxWidth: "700px", margin: "auto" }}>
            <Bar ref={chartRef} data={chartData} />
          </div>
          <button style={{ marginTop: "20px", padding: "8px 20px" }} onClick={generatePDF}>
            📄 Télécharger le PDF
          </button>
          <h3 style={{ marginTop: "30px" }}>Détails</h3>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#f0f0f0" }}>
                <th style={{ border: "1px solid #ccc", padding: "6px" }}>Utilisateur</th>
                <th style={{ border: "1px solid #ccc", padding: "6px" }}>Moyenne EEG</th>
                <th style={{ border: "1px solid #ccc", padding: "6px" }}>Echantillons</th>
              </tr>
            </thead>
            <tbody>
              {table.map((row, idx) => (
                <tr key={idx}>
                  <td style={{ border: "1px solid #ccc", padding: "6px" }}>{row.uid}</td>
                  <td style={{ border: "1px solid #ccc", padding: "6px" }}>{row.avg}</td>
                  <td style={{ border: "1px solid #ccc", padding: "6px" }}>{row.samples}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      ) : (
        <p>Chargement des données...</p>
      )}
    </div>
  );
};

export default SionohmairReport;