
import React, { useEffect, useState } from 'react';
import { getEEGSessions } from '../services/eegService';
import { getCoachingSessions } from '../services/coachingService';

const ProfilePage = () => {
  const [eegSessions, setEegSessions] = useState([]);
  const [coachingSessions, setCoachingSessions] = useState([]);

  const userId = '00000000-0000-0000-0000-000000000000'; // Remplacer par une authentification réelle

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const eegData = await getEEGSessions(userId);
        const coachingData = await getCoachingSessions(userId);
        setEegSessions(eegData);
        setCoachingSessions(coachingData);
      } catch (error) {
        console.error('Erreur récupération Supabase :', error);
      }
    };
    fetchSessions();
  }, []);

  return (
    <div className="bg-white dark:bg-gray-100 rounded-lg shadow-md p-6 h-full overflow-auto">
      <h2 className="text-2xl font-bold text-blue-900 dark:text-gray-800 mb-4">Profil Utilisateur</h2>
      <p className="text-gray-700 dark:text-gray-800 mb-4">
        Historique de vos sessions EEG et de coaching.
      </p>

      <div className="bg-gray-50 dark:bg-white p-4 rounded shadow-inner mb-6">
        <h3 className="text-lg font-semibold mb-2">🧠 Sessions EEG</h3>
        <table className="w-full table-auto text-left text-sm">
          <thead>
            <tr className="text-gray-700 dark:text-gray-900">
              <th className="p-2">Date</th>
              <th className="p-2">Dominante</th>
              <th className="p-2">Résumé</th>
            </tr>
          </thead>
          <tbody>
            {eegSessions.map((session) => (
              <tr key={session.id} className="hover:bg-gray-100">
                <td className="p-2">{new Date(session.date).toLocaleDateString()}</td>
                <td className="p-2">{session.dominante}</td>
                <td className="p-2">{session.résumé}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-gray-50 dark:bg-white p-4 rounded shadow-inner">
        <h3 className="text-lg font-semibold mb-2">🧭 Sessions Coaching</h3>
        <table className="w-full table-auto text-left text-sm">
          <thead>
            <tr className="text-gray-700 dark:text-gray-900">
              <th className="p-2">Date</th>
              <th className="p-2">Type</th>
              <th className="p-2">Résumé</th>
            </tr>
          </thead>
          <tbody>
            {coachingSessions.map((session) => (
              <tr key={session.id} className="hover:bg-gray-100">
                <td className="p-2">{new Date(session.date).toLocaleDateString()}</td>
                <td className="p-2">{session.type}</td>
                <td className="p-2">{session.résumé}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProfilePage;
