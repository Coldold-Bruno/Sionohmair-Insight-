
import React from 'react';
import Sidebar from '../components/Sidebar';

const AccueilPage = () => {
  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-grow p-10 bg-white dark:bg-gray-100 overflow-y-auto">
        <h1 className="text-4xl font-bold mb-6 text-blue-900 dark:text-gray-800">Bienvenue dans Sionohmair Insight</h1>
        <p className="text-lg text-gray-700 dark:text-gray-900 mb-4">
          Cette application est conçue pour explorer la vibration intérieure de la pensée humaine à travers l’électromagnétisme cérébral.
          Elle s’appuie sur les principes du <strong>Sionohmair</strong>, un concept original liant neurosciences, spiritualité et cartographie de la croyance.
        </p>
        <p className="text-md text-gray-600 dark:text-gray-800">
          À travers l’analyse EEG, l’exploration vibratoire, et le coaching cognitif, vous pouvez :
          <ul className="list-disc list-inside mt-2 ml-4">
            <li>Visualiser vos ondes cérébrales en temps réel</li>
            <li>Cartographier vos pensées selon des axes conceptuels uniques</li>
            <li>Recevoir un accompagnement personnalisé en accord avec votre vibration mentale</li>
          </ul>
        </p>
        <div className="mt-8 text-center">
          <p className="italic text-gray-500">"La vibration de la pensée n’est pas un bruit : c’est un chant intérieur." – Manuscrit du Sionohmair</p>
        </div>
      </main>
    </div>
  );
};

export default AccueilPage;
