
import React from 'react';
import useMuse from '../hooks/useMuse';
import EEGChart from '../components/EEGChart';

const EEGPage = () => {
  const { eegData } = useMuse();

  return (
    <div className="bg-white dark:bg-gray-100 rounded-lg shadow-md p-6 h-full overflow-auto">
      <h2 className="text-2xl font-bold text-blue-900 dark:text-gray-800 mb-4">EEG en temps réel</h2>
      <p className="text-gray-700 dark:text-gray-800 mb-6">
        Suivez l'activité électroencéphalographique captée en direct depuis votre capteur connecté.
        Cette visualisation permet d'observer l'évolution des ondes Alpha, Beta, Theta, Gamma, Delta.
      </p>
      <div className="bg-gray-50 dark:bg-white rounded p-4 shadow-inner">
        <EEGChart eegData={eegData} />
      </div>
      <div className="mt-6">
        <h3 className="text-lg font-semibold text-blue-800">Statistiques</h3>
        <ul className="mt-2 list-disc list-inside text-gray-600 dark:text-gray-800">
          <li>Signal dominant : <strong>{/* à implémenter */} Alpha</strong></li>
          <li>Stabilité actuelle : <strong>{/* à implémenter */} Équilibrée</strong></li>
          <li>Tendance : <strong>{/* à implémenter */} Calme progressif</strong></li>
        </ul>
      </div>
    </div>
  );
};

export default EEGPage;
