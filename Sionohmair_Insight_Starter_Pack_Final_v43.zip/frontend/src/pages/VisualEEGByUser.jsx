import React, { useEffect, useState } from "react";
import { db } from "../config/firebase-config";
import { collection, getDocs } from "firebase/firestore";
import { Line } from "react-chartjs-2";
import "chart.js/auto";

const VisualEEGByUser = () => {
  const [entries, setEntries] = useState([]);
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState("");

  useEffect(() => {
    const load = async () => {
      const snapshot = await getDocs(collection(db, "users"));
      setUsers(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    };
    load();
  }, []);

  const loadEEG = async (userId) => {
    const snapshot = await getDocs(collection(db, "eeg_croyances"));
    const data = snapshot.docs
      .map((doc) => ({ id: doc.id, ...doc.data() }))
      .filter((e) => e.userId === userId);
    setEntries(data);
  };

  const handleChange = (e) => {
    const userId = e.target.value;
    setSelectedUser(userId);
    loadEEG(userId);
  };

  const chartData = {
    labels: entries.map((e, i) => `#${i + 1}`),
    datasets: [
      {
        label: "EEG Intensity (simulée)",
        data: entries.map((e) => parseFloat(e.eeg.match(/\d+\.?\d*/g)?.[0] || 0)),
        borderColor: "blue",
        backgroundColor: "rgba(0,0,255,0.1)",
        tension: 0.4,
      },
    ],
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>📈 Visualisation EEG & croyances</h2>
      <select value={selectedUser} onChange={handleChange} style={{ padding: "6px", marginBottom: "20px" }}>
        <option value="">– Sélectionner un utilisateur –</option>
        {users.map((u) => (
          <option key={u.id} value={u.id}>{u.email}</option>
        ))}
      </select>
      {entries.length > 0 && (
        <>
          <Line data={chartData} />
          <ul style={{ marginTop: "20px" }}>
            {entries.map((e, i) => (
              <li key={e.id} style={{ marginBottom: "8px" }}>
                <strong>#{i + 1} :</strong> EEG = {e.eeg} | Croyance : {e.croyance}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};

export default VisualEEGByUser;