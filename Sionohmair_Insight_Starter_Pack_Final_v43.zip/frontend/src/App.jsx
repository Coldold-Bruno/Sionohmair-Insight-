import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import LanguageSelector from "./components/LanguageSelector";
import WorldMapPage from "./pages/WorldMapPage";
import AdminDashboard from "./pages/AdminDashboard";
import FirebaseLogin from "./pages/FirebaseLogin";
import SionohmairReport from "./pages/SionohmairReport";

function App() {
  const { t } = useTranslation();

  return (
    <Router>
      <div className="App">
        <header>
          <h1>{t("appTitle")}</h1>
          <LanguageSelector />
          <nav>
            <Link to="/">🏠 Accueil</Link> |{" "}
            <Link to="/map">🗺️ Carte des langues</Link> |{" "}
            <Link to="/firebase-login">🔐 Connexion sécurisée</Link>
           | <Link to="/report">📊 Rapport EEG</Link></nav>
        </header>

        <main>
          <Routes>
            <Route path="/" element={<div><h2>{t("subtitle")}</h2></div>} />
            <Route path="/map" element={<WorldMapPage />} />
            <Route path="/firebase-login" element={<FirebaseLogin />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/report" element={<SionohmairReport />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;