
import React from 'react';
import Navbar from './components/Navbar';

const AnalyseGlobalePage = () => {
  return (
    <div className="flex flex-col h-screen">
      <Navbar />
      <main className="flex-grow p-6 bg-gray-100">
        <h2 className="text-3xl font-bold mb-4">Analyse Globale du Sionohmair</h2>
        <p className="text-gray-700 mb-6">
          Cette page consolidera les explorations précédentes en une analyse globale, structurée en entonnoir temporel, conforme au manuscrit.
        </p>
        <div className="border-dashed border-2 p-4 text-center text-gray-500">
          🔍 Diagramme global à insérer ici (cartographie temporelle, transitions)
        </div>
      </main>
    </div>
  );
};

export default AnalyseGlobalePage;
