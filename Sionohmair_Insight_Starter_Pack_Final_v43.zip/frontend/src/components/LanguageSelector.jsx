import React from "react";
import { useTranslation } from "react-i18next";

const LanguageSelector = () => {
  const { i18n } = useTranslation();

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  };

  return (
    <div style={{ margin: "10px 0" }}>
      <button onClick={() => changeLanguage("fr")} style={{ marginRight: "10px" }}>
        🇫🇷 Français
      </button>
      <button onClick={() => changeLanguage("en")}>
        🇬🇧 English
      </button>
    </div>
  );
};

export default LanguageSelector;