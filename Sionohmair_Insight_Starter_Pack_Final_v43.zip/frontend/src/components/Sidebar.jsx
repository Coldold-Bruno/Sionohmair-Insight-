
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, BrainCircuit, Compass, BarChart3, Activity, User, Sun, Moon } from 'lucide-react';

const Sidebar = () => {
  const location = useLocation();
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('theme') === 'dark');

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const navItems = [
    { path: '/', label: 'Accueil', icon: <Home size={20} /> },
    { path: '/eeg', label: 'EEG', icon: <BrainCircuit size={20} /> },
    { path: '/exploration', label: 'Exploration', icon: <Compass size={20} /> },
    { path: '/analyse', label: 'Analyse Globale', icon: <BarChart3 size={20} /> },
    { path: '/coaching', label: 'Coaching', icon: <Activity size={20} /> },
    { path: '/profil', label: 'Profil', icon: <User size={20} /> },
  ];

  return (
    <div className="w-64 bg-blue-900 text-white dark:bg-gray-900 min-h-screen p-6 shadow-lg flex flex-col justify-between">
      <div>
        <h1 className="text-2xl font-bold mb-8 text-center">Sionohmair</h1>
        <ul className="space-y-4">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center gap-3 px-4 py-2 rounded transition duration-200 ${
                  location.pathname === item.path ? 'bg-blue-600 dark:bg-gray-700' : 'hover:bg-blue-700 dark:hover:bg-gray-800'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
      <button
        onClick={() => setDarkMode(!darkMode)}
        className="mt-8 flex items-center justify-center gap-2 text-sm hover:text-gray-300 transition"
      >
        {darkMode ? <Sun size={18} /> : <Moon size={18} />} Mode {darkMode ? 'Clair' : 'Sombre'}
      </button>
    </div>
  );
};

export default Sidebar;
