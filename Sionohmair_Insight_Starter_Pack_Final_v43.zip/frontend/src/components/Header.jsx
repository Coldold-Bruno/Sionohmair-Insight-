
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabaseClient';

const Header = () => {
  const { user } = useAuth();

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="w-full p-4 bg-blue-900 text-white flex justify-between items-center">
      <h1 className="text-xl font-bold">Sionohmair Insight</h1>
      {user && (
        <div className="flex items-center gap-4">
          <span className="text-sm">Connecté en tant que : {user.email}</span>
          <button onClick={handleLogout} className="bg-red-600 px-3 py-1 rounded hover:bg-red-700">
            Déconnexion
          </button>
        </div>
      )}
    </div>
  );
};

export default Header;
