
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav className="p-4 bg-blue-500 text-white flex justify-around">
    <Link to="/eeg" className="hover:text-gray-300">EEG</Link>
    <Link to="/exploration" className="hover:text-gray-300">Exploration</Link>
    <Link to="/analyse" className="hover:text-gray-300">Analyse Globale</Link>
    <Link to="/coaching" className="hover:text-gray-300">Coaching</Link>
  </nav>
);

export default Navbar;
