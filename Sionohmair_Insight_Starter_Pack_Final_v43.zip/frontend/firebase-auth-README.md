# 🔐 Intégration Firebase Auth – Sionohmair Insight

Cette application inclut déjà une protection simple par mot de passe pour l'accès à la page admin.
Pour passer à une version sécurisée et scalable, voici les étapes pour intégrer Firebase Authentication :

---

## ✅ Étapes à suivre pour sécuriser l’app avec Firebase Auth

1. Crée un projet Firebase sur https://console.firebase.google.com

2. Active l’**Authentication** dans le menu Firebase > Build > Authentication

3. Active le **mode Email/Mot de passe**

4. Récupère ta configuration Firebase :
   - apiKey
   - authDomain
   - projectId
   - storageBucket
   - messagingSenderId
   - appId

5. Crée un fichier `firebase-config.js` dans `src/config/` :

```js
// src/config/firebase-config.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "TA_CLÉ_API",
  authDomain: "TON_DOMAINE.firebaseapp.com",
  projectId: "ID_DU_PROJET",
  storageBucket: "TON_BUCKET",
  messagingSenderId: "ID_MESSAGERIE",
  appId: "TON_APP_ID"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
```

6. Installe les dépendances dans le frontend :

```bash
npm install firebase
```

7. Remplace la page `AdminLogin.jsx` par une version Firebase avec création de compte et login sécurisé.

---

🧠 Tu pourras ensuite gérer :
- les rôles utilisateurs
- les accès conditionnels
- les tokens sécurisés

Contacte l’équipe Sionohmair pour obtenir les accès à la console Firebase.