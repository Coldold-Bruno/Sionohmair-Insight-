
# 🌌 Sionohmair Insight

**Sionohmair Insight** est une application web explorant l'activité cognitive et spirituelle humaine à travers des visualisations EEG, des sessions de coaching, et une cartographie consciente basée sur le manuscrit *Sionohmair de la Cartographie de la Croyance et de la Conscience*.

---

## 🔥 Fonctionnalités principales

- 🧠 Visualisation EEG en temps réel (mock data ou réelle via Muse/Emotiv)
- 💬 Sessions de coaching orientées selon les épigénomènes
- 🧭 Cartographie des croyances et de la conscience utilisateur
- 🔐 Authentification sécurisée Supabase
- 📈 Historique utilisateur EEG + Coaching
- 🧑‍💻 Espace développeur extensible avec services Supabase

---

## 🧰 Technologies utilisées

| Frontend | Auth & DB | Déploiement |
|----------|-----------|-------------|
| React    | Supabase  | Vercel      |
| Tailwind | Supabase Auth | GitHub     |
| Context API | Realtime | .env/.env.local |

---

## 🚀 Installation locale

```bash
git clone https://github.com/ton-user/sionohmair-insight.git
cd sionohmair-insight/frontend
npm install
cp .env.example .env.local  # puis remplis les clés Supabase
npm run dev
```

---

## 🌐 Déploiement Vercel (automatique)

1. Crée un compte Vercel : https://vercel.com
2. Clique sur **"Import GitHub Project"**
3. Lien vers ce repo : `sionohmair-insight`
4. Ajoute les variables d’environnement :
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Lance le déploiement 🚀

---

## 🔄 Supabase : configuration rapide

1. Créer un projet : [supabase.io](https://supabase.io)
2. Créer 3 tables :
   - `users` (id, email, ... automatique)
   - `sessions_eeg` (id, user_id, date, dominante, résumé)
   - `sessions_coaching` (id, user_id, date, type, résumé)
3. Copier les clés dans `.env.local`

---

## 📁 Structure du code

```
frontend/
├── src/
│   ├── pages/           # Pages principales
│   ├── components/      # Composants UI
│   ├── services/        # Appels Supabase
│   ├── context/         # Authentification
│   └── lib/             # Connexion Supabase
├── .env.example         # Exemples de clés
├── README.md
```

---

## 🧠 Concept Sionohmair

L'application s'appuie sur la théorie du **Sionohmair**, intégrant :
- l’électromagnétisme de la pensée
- les fractales cognitives
- une cartographie des épigénomènes
- un coaching basé sur la lumière intérieure

Pour plus d’infos, voir le fichier `MANIFESTE_SIONOHMAIR.md`

---

## 🧩 Contributions

Si tu es développeur ou chercheur en conscience :
- Fork le projet
- Propose une PR
- Ou contacte l’auteur

---

## ✨ Auteur

**Coldold Bruno Baama**  
→ Écrivain, créateur du concept Sionohmair, développeur d’idées

---


### 📚 Dépendances supplémentaires pour le rapport PDF

```bash
npm install jspdf html2canvas
```

